import icon1 from './icon1.jpg'
import basket_icon from './basket_icon.jpg'
import linkedin_icon from './linkedin_icon.jpg'
import facebook_icons from './facebook_icons.jpg'
import twitter_icon from './twitter_icon.jpg'
import app_store_icon from './app_store_icon.jpg'
import play_store_icon from './play_store_icon.jpg'
import icons2 from './icons2.jpg'
import icon3 from './icon3.jpg'
import icon4 from './icon4.jpg'
import icon5 from './icon5.jpg'
import logo1 from './logo1.jpg'
import pictures from './pictures.jpg'
import iconics from './iconics.jpg'
import menu1 from './menu1.jpg'
import menu2 from './menu2.jpg'
import menu3 from './menu3.jpg'
import menu4 from './menu4.jpg'
import menu5 from './menu5.jpg'
import menu7 from './menu7.jpg'
import menu8 from './menu8.jpg'
import menu9 from './menu9.jpg'


import food_1 from './food_1.jpg'
import food_2 from './food_2.jpg'
import food_3 from './food_3.jpg'
import food_4 from './food_4.jpg'
import food_5 from './food_5.jpg'
import food_6 from './food_6.jpg'
import food_7 from './food_7.jpg'
import food_8 from './food_8.jpg'
import food_9 from './food_9.jpg'
import food_10 from './food_10.jpg'
import food_11 from './food_11.jpg'
import food_12 from './food_12.jpg'
import food_13 from './food_13.jpg'
import food_14 from './food_14.jpg'
import food_15 from './food_15.jpg'
import food_16 from './food_16.jpg'
import food_17 from './food_17.jpg'
import food_18 from './food_18.jpg'
import food_19 from './food_19.jpg'
import food_20 from './food_20.jpg'
import food_21 from './food_21.jpg'
import food_22 from './food_22.jpg'
import food_23 from './food_23.jpg'
import food_24 from './food_24.jpg'
import food_25 from './food_25.jpg'
import food_26 from './food_26.jpg'
import food_27 from './food_27.jpg'
import food_28 from './food_28.jpg'
import food_29 from './food_29.jpg'
import food_30 from './food_30.jpg'
import food_31 from './food_31.jpg'
import food_32 from './food_32.jpg'
import food_33 from './food_33.jpg'
import ali_icon from './ali_icon.jpg'
import bali_icon from './bali_icon.jpg'
import cali_icon from './cali_icon.jpg'
import parcel_icon from './parcel_icon.jpg'




import pic15 from './pic15.jpg'
import pic16 from './pic16.jpg'


export const assets={
    ali_icon,
    bali_icon,
    cali_icon,
    basket_icon,
    icon1,
    icons2,
    icon3,
    icon4,
    icon5,
    logo1,
    pictures,
    iconics,
    facebook_icons,
    twitter_icon,
    linkedin_icon,
    app_store_icon,
    play_store_icon,
    parcel_icon,
    menu1,
    menu2,
    menu3,
    menu4,
    menu5,
    menu7,
    menu8,
    menu9,

    food_1,
    food_2,
    food_3,
    food_4,
    food_5,
    food_6,
    food_7,
    food_8,
    food_9,
    food_10,
    food_11,
    food_12,
    food_13,
    food_14,
    food_15,
    food_16,
    food_17,
    food_18,
    food_19,
    food_20,
    food_21,
    food_22,
    food_23,
    food_24,
    food_25,
    food_26,
    food_27,
    food_28,
    food_29,
    food_30,
    food_31,
    food_32,
    food_33,

    
    
   
    pic15,
    pic16,

}
export const menu_list=[
    {
       
        menu_image:menu1,
        menu_name: "Salad"
    },
    {
       
        menu_image:menu2,
         menu_name: "Rolls"
    },
    {
        
        menu_image:menu3,
         menu_name: "Biriyani"
    },
    {
        
        menu_image:menu4,
         menu_name: "Sandwich"
    },
    {
       
        menu_image:menu5,
         menu_name: "Noodles"
    },
    {
       
        menu_image:menu7,
         menu_name: "Pasta"
    },
    {
       
        menu_image:menu8,
         menu_name: "Pure Veg"
    },
    {
       
        menu_image:menu9,
         menu_name: "Desert"
    }
    
    ];
 export const food_list=[
    {
        _id: "1", 
        name: "Greek salad",
        image: food_1, 
        price: 12,
        description: "Food provides essential nutrients for overall health and well-being", 
        category: "Salad"
    },
           {
            _id: "2", 
            image: food_2,
            name: "Veg salad",
            price: 18,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Salad"
           },
        {
            _id: "3", 
            image: food_3,
            name: "grey salad",
            price: 19,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Salad" 
        },
        {
            _id: "4", 
            image: food_4,
            name: " Chicken salad",
            price: 18,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "salad"
        },
        {
            _id: "5", 
            image: food_5,
            name: "Chicken Rolls",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Rolls"
        },
        {
            _id: "6", 
            image: food_6,
            name: "Shawari Rolls",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Rolls"
        },
        {
            _id: "7", 
            image: food_7,
            name: "Shawarma Rolls",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Rolls"
        },
        {
            _id: "8", 
            image: food_8,
            name: "Meet  Rolls",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Rolls"
        },
        {
            _id: "9", 
            image: food_9,
            name: "Chicken biriyani",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Biriyani"
        },
        {
            _id: "10", 
            image: food_10,
            name: "Egg biriyani",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Biriyani"
        },
        {
            _id: "11", 
            image: food_11,
            name: "White biriyani",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Biriyani"
        },
        {
            _id: "12", 
            image: food_12,
            name: "Vegetable biriyani",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Biriyani"
        },
        {
            _id: "13", 
            image: food_13,
            name: "Chicken Sandwich",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Sandwich"
        },
        {
            _id: "14", 
            image: food_14,
            name: "Vegan Sandwich",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Sandwich"
        },
        {
            _id: "15", 
            image: food_15,
            name: "Grilled Sandwich",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Sandwich"
        },
        {
            _id: "16", 
            image: food_16,
            name: "Bread Sandwich",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Sandwich"
        },
        {
            _id: "17", 
            image: food_17,
            name: "Chicken Noodles",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Noodles"
        },
        {
            _id: "18", 
            image: food_18,
            name: "Egg Noodles",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Noodles"
        },
        {
            _id: "19", 
            image: food_19,
            name: "Veg Noodles",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Noodles"
        },
        {
            _id: "20", 
            image: food_20,
            name: "Fried Noodles",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Noodles"
        },
        {
            _id: "21", 
            image: food_21,
            name: "Fried Pasta",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Pasta"
        },
        {
            _id: "22", 
            image: food_22,
            name: "Long Pasta",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Pasta"
        },
        {
            _id: "23", 
            image: food_23,
            name: "Chicken Pasta",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Pasta"
        },
        {
            _id: "24", 
            image: food_24,
            name: "Egg Pasta",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Pasta"
        },
        {
            _id: "25", 
            image: food_25,
            name: "Garlic Mashroom",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Pure Veg"
        },
        {
            _id: "26", 
            image: food_26,
            name: "Fried Cauliflower",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Pure Veg"
        },
        {
            _id: "27", 
            image: food_27,
            name: "Mix Veg Pulao",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Pure Veg"
        },
        {
            _id: "28", 
            image: food_28,
            name: "Rice Zucchi",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Pure Veg"
        },
        {
            _id: "29", 
            image: food_29,
            name: "Ripple Ice Cream",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Desert"
        },
        {
            _id: "30", 
            image: food_30,
            name: "Fruit Ice Cream",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Desert"
        },
        {
            _id: "31", 
            image: food_31,
            name: "Jar Ice Cream",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Desert"
        },
        {
            _id: "32", 
            image: food_32,
            name: "Vanilla Ice Cream",
            price: 110,
            description: "Food provides essential nutrients for overall health andwell-being",
            category: "Desert"
        },
        

    ];
